import React from 'react'
import Header from '../Common/Header'

function SingleCourse() {
  return (
    <>
    <Header/>
</>
  )
}

export default SingleCourse