import img1 from '../img/t8.jpg'
import img2 from '../img/t2.jpg'
import img3 from '../img/t1.jpg'
import img4 from '../img/t4.jpg'
import img5 from '../img/t5.jpg'
import img6 from '../img/t7.jpg'
import t1 from '../img/f3 (1).png'
import t2 from '../img/f3 (2).png'
import t3 from '../img/f3 (3).png'
import t4 from '../img/f3 (4).png'
import t5 from '../img/f3.png'

export let tabsdata = [
 
    {
        category:"Desgin",
        image:img2,
        meta:"Updated 21/12/19",
        head:"Fashion Photography From Professional",
        fee:"FREE"
    },
    {
        category:"Desgin",
        image:img3,
        meta:"Updated 21/12/19",
        head:"react",
        fee:"FREE"
    },
    {
        category:"Desgin",
        image:img1,
        meta:"Updated 21/12/19",
        head:"Fashion Photography From Professional",
        fee:"FREE"
    },
    {
        category:"Desgin",
        image:img5,
        meta:"Updated 21/12/19",
        head:"Fashion Photography From Professional",
        fee:"FREE"
    },
    {
        category:"Desgin",
        image:img4,
        meta:"Updated 21/12/19",
        head:"Fashion Photography From Professional",
        fee:"FREE"
    },
    {
        category:"3D + Animation",
        image:img6,
        meta:"Updated 21/12/19",
        head:"Fashion Photography From Professional",
        fee:"FREE"
    },
    {
        category:"3D + Animation",
        image:img5,
        meta:"Updated 21/12/19",
        head:"Fashion Photography From Professional",
        fee:"FREE"
    },
    {
        category:"3D + Animation",
        image:img3,
        meta:"Updated 21/12/19",
        head:"Fashion Photography From Professional",
        fee:"FREE"
    },
   
]

export const teamData = [
    {
        bg:t1,
        subject:"PHP , Larvel"
    },
    {
       bg:t2,
       subject:"React , Node"

    },
    {
       bg:t3,
       subject:"Garphic , Photoshop"

    },
    {
        bg:t4,
        subject:"Angular"

    },
    {
        bg:t5,
        subject:"Web Design , Figma"
        
    },
  
]