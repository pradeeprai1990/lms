export const dashboardData = [
    {
        heading:'Today’s Bookings',
        count:4006,
        para:'10.00% (30 days)',
        color:'#7DA0FA'
    },
    {
        heading:'Total Bookings',
        count:61344,
        para:'22.00% (30 days)',
        color:'#4747A1'

    },
    {
        heading:'Number of Meetings',
        count:34040,
        para:'2.00% (30 days)',
        color:'#7978E9'

    },
    {
        heading:'Number of Clients',
        count:47033,
        para:'0.22% (30 days)',
        color:'#F3797E'

    },
    
]